from __future__ import annotations

import os
import getpass

# Constants

USER_NAME                  = getpass.getuser()
CURRENT_PROCESS_IDENTIFIER = os.getpid()

CELL_SCALE_UNITS           = 2.4
MAZE_DIMENSION             = 44
WALL_HEIGHT_UNITS          = 2.8

MONSTER_MOVE_SPEED         = 4.0
GLITCH_PROXIMITY_RADIUS    = 5.5
COLLAPSE_CHANCE_PERCENT    = 0.008
RADAR_RANGE_METERS         = 26.0
FRAMES_PER_SECOND_SPRITE   = 20
RADAR_SCANNER_TEXTURE_SIZE = 256

FPS_120                    = 8
FPS_60                     = 16
FPS_30                     = 32

WALL_DECAL_TEXT_COLLECTION = [
    "they say DON'T LOOK BACK",
    "im tired",
    "KEEP MOVING but why",
    "NO EXIT",
    "HELP ME",
    "WHY AM I STILL HERE",
    "LET ME SLEEP",
    "IT'S IN THE WALLS",
    "When will this end?"
]

FALLBACK_SOURCE_CODE_LINES = [
    "sys.exit(app.exec())",
    "QAudioSink.start()",
    "while not crashed:",
    "glDrawArrays(GL_TRIANGLES)",
    "return float('inf')",
    "0xDEADBEEF LEAK",
    "segmentation fault",
    "throw std::bad_alloc()",
    "kernel panic"
]