from __future__ import annotations

from PyQt6.QtGui import QFont

from PyQt6.QtCore import (
    Qt,
    QTimer
)

from PyQt6.QtWidgets import (
    QLabel,
    QMainWindow
)

from . import Constants
from .Widget import AuditSimulationWidget

# Audit Window Wrapper

class AuditExecutionWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        self.setWindowTitle(f"Core // Cassette Memory Dump [PID: {Constants.CURRENT_PROCESS_IDENTIFIER}]")
        self.resize(1100, 800)

        self.simulation_widget = AuditSimulationWidget(self)
        self.setCentralWidget(self.simulation_widget)

        self.intro_osd_label = QLabel(f"REC  ▶\nUSER {Constants.USER_NAME}\nFATE {self.simulation_widget.run_fate_scenario}", self)
        self.intro_osd_label.setFont(QFont("Monospace", 20, QFont.Weight.Bold))
        self.intro_osd_label.setStyleSheet("color: #2bf04c; background-color: transparent; letter-spacing: 3px;")
        self.intro_osd_label.move(40, 40)
        self.intro_osd_label.show()

        self.hud_message_label = QLabel("[ Take the scanner. ]", self)
        self.hud_message_label.setFont(QFont("Impact", 21))
        self.hud_message_label.setStyleSheet("color: #30f040; background-color: rgba(0, 0, 0, 160); padding: 6px 16px; border-radius: 6px;")
        self.hud_message_label.adjustSize()
        self.hud_message_label.move((self.width() - self.hud_message_label.width()) // 2, 60)
        self.hud_message_label.show()

    def hide_intro_osd(self) -> None:
        self.intro_osd_label.hide()

    def display_onscreen_message(self, message_text: str) -> None:
        self.hud_message_label.setText(message_text)
        self.hud_message_label.adjustSize()
        self.hud_message_label.move((self.width() - self.hud_message_label.width()) // 2, 60)
        self.hud_message_label.show()

        QTimer.singleShot(5500, self.hud_message_label.hide)