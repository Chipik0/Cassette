from __future__ import annotations

import math
import numpy

from System.Services import Player
from . import WorldBuilder

# Base Scenario

class FateScenario:
    name: str = "BASE"

    def setup_world(self, simulation_widget: object) -> None:
        pass

    def update(
            self,
            simulation_widget:  object,
            delta_time_seconds: float
        ) -> None:

        pass

    def get_radar_status_text(self, simulation_widget: object) -> str:
        return f"WAYPOINT #{simulation_widget.current_waypoint_index + 1} // OK"

# Specific Fate Scenarios

class StandardFate(FateScenario):
    name: str = "STANDARD"

    def update(
            self,
            simulation_widget:  object,
            delta_time_seconds: float
        ) -> None:

        if not simulation_widget.solution_path_points:
            return

        terminal_point     = simulation_widget.solution_path_points[-1]
        cell_scale         = simulation_widget.cell_scale_units
        distance_to_finish = math.hypot(
            simulation_widget.camera_position[0] - (terminal_point[0] + 0.5) * cell_scale,
            simulation_widget.camera_position[2] - (terminal_point[1] + 0.5) * cell_scale
        )

        has_reached_threshold = (
            distance_to_finish < 4.5 or (
                simulation_widget.device_picked_up and
                simulation_widget.current_waypoint_index > len(simulation_widget.solution_path_points) * 0.65
            )
        )

        if has_reached_threshold and not simulation_widget.finale_sequence_active:
            simulation_widget.finale_sequence_active = True
            audio_pan = simulation_widget.calculate_audio_pan(
                float(simulation_widget.corridor_entrance_position[0]),
                float(simulation_widget.corridor_entrance_position[2])
            )
            Player.ui_player.play_sound(".vault/Anomaly/SparkPop", pan = audio_pan)
            simulation_widget.parent().display_onscreen_message("Something is coming for you.")

            simulation_widget.monster_entity_position    = numpy.copy(simulation_widget.corridor_entrance_position)
            simulation_widget.monster_entity_position[1] = 0.0
            simulation_widget.monster_entity_active      = True
            simulation_widget.monster_path_waypoints     = WorldBuilder.find_shortest_grid_path(
                simulation_widget.monster_entity_position,
                simulation_widget.camera_position,
                simulation_widget.world_grid_array,
                simulation_widget.cell_scale_units,
                simulation_widget.maze_dimension
            )

        if not simulation_widget.finale_sequence_active:
            return

        simulation_widget.finale_timer_seconds += delta_time_seconds
        distance_to_monster                     = math.hypot(
            simulation_widget.camera_position[0] - simulation_widget.monster_entity_position[0],
            simulation_widget.camera_position[2] - simulation_widget.monster_entity_position[2]
        )

        simulation_widget.heartbeat_timer_seconds -= delta_time_seconds

        if simulation_widget.heartbeat_timer_seconds <= 0.0:
            simulation_widget.heartbeat_timer_seconds = float(numpy.clip(distance_to_monster / 18.0, 0.22, 1.05))
            Player.ui_player.play_sound(".vault/Anomaly/Heartbeat")

        simulation_widget.monster_repath_timer -= delta_time_seconds

        if simulation_widget.monster_repath_timer <= 0.0:
            simulation_widget.monster_repath_timer   = 0.22
            simulation_widget.monster_path_waypoints = WorldBuilder.find_shortest_grid_path(
                simulation_widget.monster_entity_position,
                simulation_widget.camera_position,
                simulation_widget.world_grid_array,
                simulation_widget.cell_scale_units,
                simulation_widget.maze_dimension
            )

        simulation_widget.monster_entity_position = simulation_widget.step_entity_navigation(
            simulation_widget.monster_entity_position,
            simulation_widget.monster_path_waypoints,
            simulation_widget.monster_movement_speed * 1.30,
            delta_time_seconds,
            is_monster = True
        )

        if distance_to_monster <= 1.45:
            Player.ui_player.play_sound(".vault/Anomaly/VisceralScream")
            simulation_widget.jumpscare_blood_factor = min(1.0, simulation_widget.jumpscare_blood_factor + delta_time_seconds * 4.5)
            simulation_widget.reality_tear_ratio     = 1.0

        if distance_to_monster <= 0.88 or simulation_widget.jumpscare_blood_factor >= 0.96:
            simulation_widget.finalize_easter_egg_termination("Caught.")


class BurnoutFate(FateScenario):
    name: str = "BURNOUT"

    def setup_world(self, simulation_widget: object) -> None:
        dimension  = simulation_widget.maze_dimension
        scale_unit = simulation_widget.cell_scale_units

        minimum_bound, maximum_bound = 12, 32
        simulation_widget.world_grid_array[minimum_bound:maximum_bound, minimum_bound:maximum_bound] = 0

        coordinate_x, coordinate_z = 22, 22
        simulation_widget.camera_position       = numpy.array([(coordinate_x + 0.5) * scale_unit, 1.4, (coordinate_z + 0.5) * scale_unit], dtype = numpy.float32)
        simulation_widget.device_world_position = numpy.array([(coordinate_x + 0.5) * scale_unit, 0.2, (coordinate_z + 1.4) * scale_unit], dtype = numpy.float32)

        simulation_widget.yaw_degrees          = 90.0
        simulation_widget.target_yaw_degrees   = 90.0
        simulation_widget.solution_path_points = [(coordinate_x, coordinate_z)]
        simulation_widget.lamp_world_positions = []

        for lamp_x in range(minimum_bound + 2, maximum_bound - 2, 4):
            for lamp_z in range(minimum_bound + 2, maximum_bound - 2, 4):
                simulation_widget.lamp_world_positions.append(((lamp_x + 0.5) * scale_unit, (lamp_z + 0.5) * scale_unit))

    def update(
            self,
            simulation_widget:  object,
            delta_time_seconds: float
        ) -> None:

        simulation_widget.madness_ratio = min(1.0, simulation_widget.elapsed_time_seconds * 0.015)

        if simulation_widget.elapsed_time_seconds <= 45.0:
            return

        simulation_widget.finale_sequence_active = True
        simulation_widget.finale_timer_seconds  += delta_time_seconds
        simulation_widget.heavy_eyelids_factor   = min(1.0, simulation_widget.finale_timer_seconds / 7.0)
        simulation_widget.camera_position[1]     = max(0.20, simulation_widget.camera_position[1] - delta_time_seconds * 0.22)
        simulation_widget.target_pitch_degrees   = min(40.0, simulation_widget.target_pitch_degrees + delta_time_seconds * 8.0)

        if simulation_widget.finale_timer_seconds > 3.0 and simulation_widget.finale_timer_seconds - delta_time_seconds <= 3.0:
            simulation_widget.parent().display_onscreen_message("Just lay down.")

        if simulation_widget.finale_timer_seconds >= 8.5:
            simulation_widget.finalize_easter_egg_termination("Apathy kills.")

    def get_radar_status_text(self, simulation_widget: object) -> str:
        return "NO REACHABLE EXIT // TIRED"


class GravityFate(FateScenario):
    name: str = "GRAVITY"

    def setup_world(self, simulation_widget: object) -> None:
        simulation_widget.gravity_tilt = 12.0

    def update(
            self,
            simulation_widget:  object,
            delta_time_seconds: float
        ) -> None:

        StandardFate().update(simulation_widget, delta_time_seconds)


class RadarGlitchFate(FateScenario):
    name: str = "RADAR_GLITCH"

    def setup_world(self, simulation_widget: object) -> None:
        chosen_point = simulation_widget.choose_random_floor_coordinate(10.0)
        simulation_widget.bogus_waypoint_position = numpy.array(chosen_point, dtype = numpy.float32)

    def update(
            self,
            simulation_widget:  object,
            delta_time_seconds: float
        ) -> None:

        StandardFate().update(simulation_widget, delta_time_seconds)

    def get_radar_status_text(self, simulation_widget: object) -> str:
        titles = ["0x0F: DEVIATION", "SIGNAL BOUNCE", "RECALCULATING...", "ECHO IN WALLS"]
        current = titles[int(simulation_widget.elapsed_time_seconds * 2.0) % len(titles)]
        return f"{current} #{simulation_widget.radar_chase_count + 1}"


class SilentHelpFate(FateScenario):
    name: str = "SILENT_HELP"

    def update(
            self,
            simulation_widget:  object,
            delta_time_seconds: float
        ) -> None:

        if not simulation_widget.solution_path_points:
            return

        terminal_node      = simulation_widget.solution_path_points[-1]
        scale_unit         = simulation_widget.cell_scale_units
        distance_to_finish = math.hypot(
            simulation_widget.camera_position[0] - (terminal_node[0] + 0.5) * scale_unit,
            simulation_widget.camera_position[2] - (terminal_node[1] + 0.5) * scale_unit
        )

        should_spawn = (
            distance_to_finish < 3.2 or
            simulation_widget.current_waypoint_index >= len(simulation_widget.solution_path_points) - 1
        )

        if should_spawn and not simulation_widget.sprite_entity_active:
            simulation_widget.spawn_chipsa_behind_player()

        if not simulation_widget.sprite_entity_active:
            return

        if simulation_widget.chipsa_following_state and not simulation_widget.finale_sequence_active:
            simulation_widget.chipsa_follow_timer -= delta_time_seconds
            offset_to_player                       = simulation_widget.camera_position - simulation_widget.sprite_entity_position
            offset_to_player[1]                    = 0.0
            player_distance                        = numpy.linalg.norm(offset_to_player)

            simulation_widget.chipsa_repath_timer -= delta_time_seconds

            if simulation_widget.chipsa_repath_timer <= 0.0:
                simulation_widget.chipsa_repath_timer   = 0.35
                simulation_widget.chipsa_path_waypoints = WorldBuilder.find_shortest_grid_path(
                    simulation_widget.sprite_entity_position,
                    simulation_widget.camera_position,
                    simulation_widget.world_grid_array,
                    simulation_widget.cell_scale_units,
                    simulation_widget.maze_dimension
                )

            if player_distance > 3.2:
                follow_speed = 4.0 if player_distance > 6.0 else 2.5
                simulation_widget.sprite_entity_position = simulation_widget.step_entity_navigation(
                    simulation_widget.sprite_entity_position,
                    simulation_widget.chipsa_path_waypoints,
                    follow_speed,
                    delta_time_seconds
                )

            if simulation_widget.chipsa_follow_timer <= 0.0:
                simulation_widget.finale_sequence_active = True

        if not simulation_widget.finale_sequence_active:
            return

        simulation_widget.finale_timer_seconds += delta_time_seconds
        simulation_widget.cut_to_black_factor   = min(1.0, simulation_widget.finale_timer_seconds / 4.0)

        if simulation_widget.finale_timer_seconds >= 4.2:
            simulation_widget.finalize_easter_egg_termination("Is it over yet?")


class WeepingFate(StandardFate):
    name: str = "WEEPING"

# Registry

AVAILABLE_FATE_REGISTRY: dict[str, type[FateScenario]] = {
    "STANDARD":     StandardFate,
    "BURNOUT":      BurnoutFate,
    "GRAVITY":      GravityFate,
    "RADAR_GLITCH": RadarGlitchFate,
    "SILENT_HELP":  SilentHelpFate,
    "WEEPING":      WeepingFate
}

def create_fate_scenario(scenario_name: str) -> FateScenario:
    scenario_class = AVAILABLE_FATE_REGISTRY.get(scenario_name, StandardFate)
    return scenario_class()